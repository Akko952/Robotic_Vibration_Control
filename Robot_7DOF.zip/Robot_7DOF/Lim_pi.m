function th=Lim_pi(thi)
ToDeg = 180/pi;  %ת�Ƕ�
ToRad = pi/180;  %ת����
thi=thi*ToRad;
if thi>pi
    thi=thi-2*pi;
else
    if thi<-pi
        thi=thi+2*pi;
    end
end
th=thi*ToDeg;